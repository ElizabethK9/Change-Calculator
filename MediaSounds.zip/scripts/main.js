function makeChange(input) {
    const QUARTERS_VALUE = 25;
    const DIMES_VALUE = 10;
    const NICKELS_VALUE = 5;
    const PENNIES_VALUE = 1;

    // Remove $ symbol if present
    if (input.includes('$')) {
        input = input.replace('$', '');
    }

    // Check if input contains a decimal point
    if (input.includes('.')) {
        // If it does, interpret it as a dollar amount and convert to cents
        var amount = Math.round(parseFloat(input) * 100);
    } else {
        // If it doesn't, interpret it as cents
        var amount = parseInt(input);
    }
    
    var quarters = Math.floor(amount / QUARTERS_VALUE);
    amount %= QUARTERS_VALUE;

    var dimes = Math.floor(amount / DIMES_VALUE);
    amount %= DIMES_VALUE;

    var nickels = Math.floor(amount / NICKELS_VALUE);
    amount %= NICKELS_VALUE;
    
    var pennies = amount;  // Remaining amount is all pennies

    document.getElementById('quarters').innerText = quarters;
    document.getElementById('dimes').innerText = dimes;
    document.getElementById('nickels').innerText = nickels;
    document.getElementById('pennies').innerText = pennies;
}
var coins = document.getElementById("Coins");
function playSound() {
    coins.play();
    alert("does it work?")
}